package shiros.database;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import shiros.entity.Account;
import shiros.entity.Risk;
import shiros.exception.DBException;

public class RiskRepository extends Repository {

	public RiskRepository() throws DBException {
		super();
	}
	
	/**
	 * Find Risk
	 * 
	 * @return Risk
	 * @throws DBException
	 */
	public Risk find(int id) throws DBException {
		String query = "SELECT * FROM public.\"Risk\" WHERE id = ?";

		try {
			PreparedStatement stmt = this.connection.prepareStatement(query);
			stmt.setInt(1, id);
			ResultSet result = stmt.executeQuery();
			
			if (result.next()) {				
				int riskId = result.getInt("id");
				String name = result.getString("name_risk");
				
				Risk risk = new Risk();
				risk.setId(riskId)
					.setName(name);	

				return risk;			
			} else {
				throw new DBException(String.format("The risk for id %d doesn't exist", id), null);
			}
		} catch(SQLException sqlException) {
			throw new DBException(String.format("Error during the find risk query for id %d", id), sqlException);
		}		
	}
}
