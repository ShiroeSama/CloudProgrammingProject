package shiros.database;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import shiros.entity.Account;
import shiros.entity.Risk;
import shiros.exception.DBException;
import shiros.exception.ShirOSException;

public class AccountRepository extends Repository {

	protected RiskRepository riskRepository;
	
	public AccountRepository() throws DBException {
		super();
		this.riskRepository = new RiskRepository();
	}
	
	/**
	 * Get all account
	 * 
	 * @return List<Account>
	 * @throws DBException
	 */
	public List<Account> select() throws DBException {
		String query = "SELECT * FROM public.\"BankAccount\"";

		try {
			Statement stmt = this.connection.createStatement();
			ResultSet results = stmt.executeQuery(query);
			
			List<Account> accounts = new ArrayList<Account>();
			
			while(results.next()) {
				int id = results.getInt("id");
				String name = results.getString("account_name");
				String lastname = results.getString("last_name");
				String firstname = results.getString("first_name");
				Double amount = results.getDouble("amount");
				int riskId = results.getInt("idRisk");
								
				Risk risk;
				try {
					risk = this.riskRepository.find(riskId);	
				} catch (ShirOSException shirosException) {
					throw new DBException(String.format("Failed to find the risk id %s for account %d", riskId, id), shirosException);
				}
				
				Account account = new Account();
				account.setId(id)
					.setName(name)
					.setLastname(lastname)
					.setFirstname(firstname)
					.setAmount(amount)
					.setRisk(risk);
				
				accounts.add(account);
			}
			
			return accounts;
		} catch(SQLException sqlException) {
			throw new DBException("Error during the select account query", sqlException);
		}
	}
	
	public void add() {
		
	}
	
	public void delete() {
		
	}
}
