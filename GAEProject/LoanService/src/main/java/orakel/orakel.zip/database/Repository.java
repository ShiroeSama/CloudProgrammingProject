package shiros.database;

import java.net.URI;
import java.sql.*;

import shiros.exception.DBException;

public abstract class Repository
{
	//protected String databaseUrl = "postgres://ixkjgacjrotshg:fa94c3bd5940d8bbf677c52749a5cc8c6cae1ff451b8946e9befb063d8e82b4b@ec2-54-243-28-109.compute-1.amazonaws.com:5432/d1nfump0vhgpj8";
	protected String databaseUrl = "postgres://wsccixbtuidyta:1f0e386b68be62083503cae79a231e7888ca2a8870932f7e58a9cf65fd10ad84@ec2-54-235-90-200.compute-1.amazonaws.com:5432/dclfn1iueip14h";
	protected Connection connection;
	
	/**
	 * Repository Constructor
	 * @throws DBException 
	 */
	public Repository() throws DBException {
		super();
		
		try {
			this.initConnection();			
		} catch (DBException dbException) {
			throw new DBException(String.format("%s Init Failed", this.getClass().getName()), dbException);
		}
	}

	public void initConnection() throws DBException {
		try {
			URI dbUri = new URI(this.databaseUrl);
			String username = dbUri.getUserInfo().split(":")[0];
		    String password = dbUri.getUserInfo().split(":")[1];
		    String dbUrl = "jdbc:postgresql://" + dbUri.getHost() + dbUri.getPath();
		
		    try {
			    this.connection = DriverManager.getConnection(dbUrl, username, password);			
			} catch (Exception exception) {
				throw new DBException("Failed to init the connection on the PostgreSQL DB.", exception);
			}
		} catch (Exception exception) {
			throw new DBException("The Database URL is not correct.", exception);
		}
	}
	
	public void closeConnection() throws DBException {
		try {
			if (!this.connection.isClosed()) {
				this.connection.close();
			}
		} catch (SQLException sqlException) {
			throw new DBException("Connection close error", sqlException);
		}
	}
}
