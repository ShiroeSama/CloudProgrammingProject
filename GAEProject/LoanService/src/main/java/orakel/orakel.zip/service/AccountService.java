package shiros.service;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import shiros.database.AccountRepository;
import shiros.entity.Account;
import shiros.exception.ShirOSException;


@Path("api/accounts")
@Produces(MediaType.APPLICATION_JSON)
public class AccountService extends Service {

    @GET
    public Response list() {    	
    	try {
    		AccountRepository repository = new AccountRepository();    		
    		List<Account> accounts = repository.select();
    		
    		repository.closeConnection();
        	return Response.ok(accounts).build();
    	} catch (ShirOSException shirosException) {
    		return this.errorHandling(shirosException);
		}
    }
}
